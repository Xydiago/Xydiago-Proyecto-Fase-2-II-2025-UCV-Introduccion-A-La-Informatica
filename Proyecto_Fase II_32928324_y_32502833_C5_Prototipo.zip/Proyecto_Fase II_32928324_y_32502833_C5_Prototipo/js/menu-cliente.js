let carrito = JSON.parse(localStorage.getItem("carrito")) || [] ;

document.getElementById("cerrar-sesion").addEventListener("click",function() {
    window.location.href ="../index.html"
});
