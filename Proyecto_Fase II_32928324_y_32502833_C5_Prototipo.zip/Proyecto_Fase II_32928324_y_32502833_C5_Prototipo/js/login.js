const usuario=[
{   
    rol: "Cliente",
    usuario: "ClienteUCV",
    password: "Central_123"
},
{
    rol: "Cajero",
    usuario: "caja_01",
    password: "Cajero#123"
},
{
    rol: "Gestión",
    usuario: "adminRoot",
    password: "cafetinAdmin"
},

];

let boton = document.getElementById("ingresar")
let rol = document.getElementById("rol")
let nombre = document.getElementById("username")
let contraseña = document.getElementById("password")
let mensaje = document.getElementById("mensaje-error")

boton.addEventListener ("click", function() {
    let rolV = rol.value;
    let usuarioV = nombre.value;
    let contraseñaV = contraseña.value;  
    
    if (usuarioV == "" || contraseñaV == "") {
        mensaje.innerText = "Completa todos los campos";
        return;
    }

    let Validacion = false;

for (let i = 0; i < usuario.length; i++) {
    if (usuario[i].usuario == usuarioV && usuario[i].password == contraseñaV && usuario[i].rol == rolV) {
      
      Validacion=true;
      break;  
    }
}

if(Validacion){
    if(rolV == "Cliente"){
        window.location.href = "cliente/menu.html";   
    }else if(rolV == "Cajero"){
        window.location.href = "personal-caja/menu.html";
    }else if(rolV == "Gestión"){
        window.location.href = "admin/menu.html";
    }
}else{
    mensaje.innerText = "Usuario, contraseña o rol incorrectos"
}

});