let historial = JSON.parse(localStorage.getItem("historial")) || [];
let carrito = JSON.parse(localStorage.getItem("carrito")) || [];

let ListaHistorial = document.getElementById("historial");
let contadormenu = document.getElementById("contador-menu");
let cerrarsesion = document.getElementById("cerrar-sesion");

function MostrarHistorial() {
    if(!ListaHistorial) return;
    
    if (historial.length === 0) {
        ListaHistorial.innerHTML = '<p class="vacio">No hay compras registradas</p>';
        return;
    }

    ListaHistorial.innerHTML = "";

    for (let i = historial.length - 1; i >= 0; i--) {
        let compra = historial[i];

        let ProductosLista = "";

        for (let j = 0; j < compra.productos.length; j++) {
          let prod = compra.productos[j];
          ProductosLista += `<div>• ${prod.emoji || "🛒"} ${prod.nombre} - ${prod.precio.toFixed(2)}$</div>`;
           
        }
        
        let ListaCompra =document.createElement("div");
        ListaCompra.className = "compra-anterior";
        ListaCompra.innerHTML =`
        <div class ="fecha"> 📅 ${compra.fecha}</div>
        <div class ="productos"> ${ProductosLista}</div>
        <div class ="total">Total: ${compra.total.toFixed(2)}$</div>
        `
        ListaHistorial.appendChild(ListaCompra)
    }
}

if (contadormenu) {
    contadormenu.innerText = carrito.length;
}

if (cerrarsesion) {
    cerrarsesion.addEventListener("click", function(){
        window.location.href = "../index.html"
    });
}

window.limpiarHistorial = function() {
    if (confirm("¿Borrar historial?")) {
        localStorage.removeItem("historial");
        historial = [];
        MostrarHistorial();
    }
};
MostrarHistorial();