let productos = JSON.parse(localStorage.getItem("productos-admin")) || [

     {
        id: 1,
        nombre: "Hamburguesa",
        precio: 6.50,
        stock: 30,
        emoji: "🍔",
        imagen: "../images/1.png"
    },
    {
        id: 2,
        nombre: "Pizza (porción)",
        precio: 5.00,
        stock: 30,
        emoji: "🍕",
        imagen: "../images/2.png"
    },
    {
        id: 3,
        nombre: "Refresco 1L",
        precio: 1.20,
        stock: 30,
        emoji: "🥤",
        imagen: "../images/3.png"
    },
    {
        id: 4,
        nombre: "Empanada",
        precio: 1.00,
        stock: 30,
        emoji: "🥟",
        imagen: "../images/4.png"
    },
    {
        id: 5,
        nombre: "Café",
        precio: 2.00,
        stock: 30,
        emoji: "☕",
        imagen: "../images/5.png"
    },
    {
        id: 6,
        nombre: "Tequeños (6 unds)",
        precio: 3.50,
        stock: 30,
        emoji: "🧀",
        imagen: "../images/6.png"
    },
    {   
        id: 7,
        nombre: "Pasticho",
        precio: 8.00,
        stock: 30,
        emoji: "🥘",
        imagen: "../images/7.png"
    },
    {   
        id: 8,
        nombre: "Agua 1.5L",
        precio: 1.90,
        stock: 30,
        emoji: "💧",
        imagen: "../images/8.png"
    },
    {
        id: 9,
        nombre: "Arizona 340ml",
        precio: 2.70,
        stock: 30,
        emoji: "🍹",
        imagen: "../images/9.png"
    },
    {
        id: 10,
        nombre: "Donas",
        precio: 1.20,
        stock: 30,
        emoji: "🍩",
        imagen: "../images/10.png"
    }
];

let listaProductos = document.getElementById("lista-productos-admin");
let cerrarsesion = document.getElementById("cerrar-sesion");

window.addEventListener("storage", function (event) {
    
    if(event.key === "productos-actualizados"){
        console.log("📦 Se han realizado cambios de productos")

        let nuevosProductos = JSON.parse(localStorage.getItem("productos-admin")) || [];

        productos.length=0

        for (let i =0;  i < nuevosProductos.length; i++) {
            productos.push(nuevosProductos[i]);
            
        }

        MostrarProductos();
    }
});

function MostrarProductos(){

    if(!listaProductos) return;

    listaProductos.innerHTML ="";

    if (productos.length === 0) {
        
        listaProductos.innerHTML = '<p class="vacio">No hay productos en el menú</p>';
        return;
    }

    for (let i = 0; i < productos.length; i++) {
        let prod = productos[i];

        let productodiv = document.createElement("div");
        productodiv.className ="producto-admin"

        productodiv.innerHTML= `

        <div class="producto-imagen">
            <img src="${prod.imagen}" alt="${prod.nombre}" style="width: 50px; height: 50px; object-fit: cover; border-radius: 5px;">
        </div>

        <div class="producto-admin-info">
        
        <span class= "producto-emoji">${prod.emoji} </span>
        <span class= "producto-nombre">${prod.nombre}</span>
        <span class= "producto-precio">${prod.precio.toFixed(2)}$</span>
        <span class= "producto-stock">${prod.stock}</span>
        </div>
        
        <div class="producto-admin-acciones">

            <button class="boton-editar" data-id="${prod.id}">✏️</button>
            <button class="boton-eliminar" data-id="${prod.id}">🗑️</button>

        </div>
    
        `;

        listaProductos.appendChild(productodiv);

    }


    let botonesEditar = document.querySelectorAll(".boton-editar")
    for (let i = 0; i < botonesEditar.length; i++) {
        botonesEditar[i].addEventListener("click", function(){

            let id= parseInt(this.getAttribute("data-id"))
            
            EditarProducto(id)
        });
    }

    let botonesEliminar = document.querySelectorAll(".boton-eliminar");
    for (let i = 0; i < botonesEliminar.length; i++) {
        botonesEliminar[i].addEventListener("click", function() {
            let id = parseInt(this.getAttribute("data-id"));
            EliminarProducto(id);
        });
    }
}

function EditarProducto(id){

    let producto = null;
    
    for (let i = 0; i < productos.length; i++) {
        if(productos[i].id === id){

            producto= productos[i];
            break;
        }
    }

    if (!producto) {
        alert("❌ Producto no encontrado");
        return;
    }

    let nuevoPrecio = prompt("Nuevo Precio ($):", producto.precio);
    if (nuevoPrecio === null) return;
    
    let precio = parseFloat(nuevoPrecio);

    if (isNaN(precio) || precio <= 0) {
        alert("❌ El precio debe ser un número  mayor a 0");
        return;
    }

    let nuevoStock = prompt("Nuevo Stock:", producto.stock);

    if(nuevoStock === null) return;

    let stock = parseInt(nuevoStock);

    if(isNaN(stock) || stock < 0){

         if (stock < 0) {
        alert("❌ El stock no puede ser negativo");
        return;
        }
    }
       
    producto.precio = precio;
    producto.stock = stock;

    localStorage.setItem("productos-admin", JSON.stringify(productos))

    localStorage.setItem("productos-actualizados", Date.now().toString());

    MostrarProductos();

    alert("✅ Producto actualizado correctamente");
}

function EliminarProducto(id){

    if(!confirm("¿Estás seguro de eliminar este producto?")){
        return;
    }

    let nuevosProductos = [];

    for (let i = 0; i < productos.length; i++) {
        if(productos[i].id !== id){

            nuevosProductos.push(productos[i]);
        }
        
    }

    productos = nuevosProductos;

    localStorage.setItem("productos-admin", JSON.stringify(productos));

    localStorage.setItem("productos-actualizados", Date.now().toString());

    MostrarProductos();

    alert("✅ Producto eliminado");
}

if (cerrarsesion) {
    cerrarsesion.addEventListener("click", function() {
        window.location.href = "../index.html";
    });
}

MostrarProductos();