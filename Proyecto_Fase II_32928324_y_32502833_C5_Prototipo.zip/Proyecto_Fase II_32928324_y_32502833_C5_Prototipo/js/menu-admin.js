let cerrarsesion = document.getElementById("cerrar-sesion");

if (cerrarsesion) {
    cerrarsesion.addEventListener("click", function(){
        window.location.href = "../index.html"
    })
}