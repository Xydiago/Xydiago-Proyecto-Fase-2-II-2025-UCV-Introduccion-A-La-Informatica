const productos = JSON.parse(localStorage.getItem("productos-admin")) || [
    {
        id: 1,
        nombre: "Hamburguesa ",
        precio: 6.50,
        stock: 30,
        emoji: "🍔",
        imagen: "../images/1.png"
    },
    {
        id: 2,
        nombre: "Pizza (porción) ",
        precio: 5.00,
        stock: 30,
        emoji: "🍕",
        imagen: "../images/2.png"
    },
    {
        id: 3,
        nombre: "Refresco 1L ",
        precio: 1.20,
        stock: 30,
        emoji: "🥤",
        imagen: "../images/3.png"
    },
    {
        id: 4,
        nombre: "Empanada ",
        precio: 1.00 ,
        stock: 30,
        emoji: "🥟",
        imagen: "../images/4.png"
    },
    {
        id: 5,
        nombre: "Café ",
        precio: 2.00,
        stock: 30,
        emoji: "☕",
        imagen: "../images/5.png"
    },
    {
        id: 6,
        nombre: "Tequeños (6 unds) ",
        precio: 3.50,
        stock: 30,
        emoji: "🧀",
        imagen: "../images/6.png"
    },
    {   
        id: 7,
        nombre: "Pasticho ",
        precio: 8.00,
        stock: 30,
        emoji:"🥘",
        imagen: "../images/7.png"
    },
    {   
        id: 8,
        nombre: "Agua 1.5L ",
        precio: 1.90,
        stock: 30,
        emoji:"💧",
        imagen: "../images/8.png"
    },
    {
        id: 9,
        nombre: "Arizona 340ml ",
        precio: 2.70,
        stock: 30,
        emoji: "🍹",
        imagen: "../images/9.png"
    },
    {
        id: 10,
        nombre: "Donas ",
        precio: 1.20,
        stock: 30,
        emoji: "🍩",
        imagen: "../images/10.png"
    },

];

let carrito = JSON.parse(localStorage.getItem("carrito-cajero")) || [];
let catalogo = document.getElementById("catalogo-cajero");
let contadormenu = document.getElementById("contador-menu");
let cerrarsesion = document.getElementById("cerrar-sesion")

window.addEventListener("storage", function (event) {
    
    if(event.key === "productos-actualizados"){
        console.log("📦 Se han realizado cambios de productos")

        let nuevosProductos = JSON.parse(localStorage.getItem("productos-admin")) || [];

        productos.length=0

        for (let i =0;  i < nuevosProductos.length; i++) {
            productos.push(nuevosProductos[i]);
            
        }

        MostrarCatalogo();
    }
});


function MostrarCatalogo() {
    catalogo.innerHTML= "";


    for (let i = 0; i < productos.length; i++) {
        let producto = productos[i];
        
        let productodiv= document.createElement("div");
        productodiv.className = "producto"

        let botonHtml = "";
        if (producto.stock > 0) {
            botonHtml =`<button class="boton-agregar" data-id="${producto.id}"> Agregar </button>`;
        }else{
            botonHtml =`<button class="boton-agotado" disabled>❌ Agotado</button>`;
            
        }

        productodiv.innerHTML = `
            <div class="producto-imagen">
                <img src="${producto.imagen}" alt="${producto.nombre}" style="width: 100%; height: auto; border-radius: 8px;">
            </div>
            <h3>${producto.nombre} ${producto.emoji}</h3>
            <p class="precio"> ${producto.precio.toFixed(2)}$</p>
            ${botonHtml}
        `;
            catalogo.appendChild(productodiv);

    }
        let botonesAgregar = document.querySelectorAll(".boton-agregar");
    
    for (let i = 0; i < botonesAgregar.length; i++) {
        botonesAgregar[i].addEventListener("click", function() {
            let id = parseInt(this.getAttribute("data-id"));
            
            for (let j = 0; j < productos.length; j++) {
                if (productos[j].id == id) {
                    
                    if (productos[j].stock > 0) {
                        
                        productos[j].stock--;
                        
                        carrito.push({
                            id: productos[j].id,
                            nombre:productos[j].nombre,
                            precio:productos[j].precio,
                            emoji:productos[j].emoji
                        });

                        localStorage.setItem("productos-admin", JSON.stringify(productos));

                         localStorage.setItem("productos-actualizados", Date.now().toString());

                        localStorage.setItem("carrito-cajero", JSON.stringify(carrito))
                    
                        if(contadormenu){
                            contadormenu.innerText =carrito.length;
                        }
                        MostrarCatalogo();

                        alert(`✅ "${productos[j].nombre}" agregado Stock restante: ${productos[j].stock}`);
                    }
                    break;
                }
            }
            
        });
    }

}


if (contadormenu) {
    contadormenu.innerText = carrito.length;
}

if (cerrarsesion) {
    cerrarsesion.addEventListener("click", function() {
        window.location.href = "../index.html";
    });
}

MostrarCatalogo();