let carrito = JSON.parse(localStorage.getItem("carrito-cajero")) || [] ;

let contador = document.getElementById("contador-menu")

contador.innerText = carrito.length;

document.getElementById("cerrar-sesion").addEventListener("click",function() {
    window.location.href ="../index.html"
});
