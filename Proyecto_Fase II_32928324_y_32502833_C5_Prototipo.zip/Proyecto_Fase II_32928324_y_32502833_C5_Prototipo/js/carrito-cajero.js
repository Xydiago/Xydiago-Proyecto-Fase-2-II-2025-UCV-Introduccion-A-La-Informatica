let carrito = JSON.parse(localStorage.getItem("carrito-cajero")) || [];
let historial = JSON.parse(localStorage.getItem("historial-cajero")) || [];
let productos = JSON.parse(localStorage.getItem("productos-admin")) || [];

let listaCarrito = document.getElementById("lista-carrito");
let Total = document.getElementById("Total");
let contadormenu = document.getElementById("contador-menu-cajero");
let vaciar = document.getElementById("vaciar-carrito");
let finalizar = document.getElementById("comprar-cajero");
let cerrarsesion = document.getElementById("cerrar-sesion");

function MostrarCarrito(){
    if (carrito.length === 0) {
        listaCarrito.innerHTML = '<p class="vacio">No hay ningun producto que vender.</p>';
        Total.innerText = "Total: 0.00$"
    }else{
        listaCarrito.innerHTML= "";
        let TotalC =0;

        for (let i = 0; i < carrito.length; i++) {
            let item = carrito [i];
            TotalC += item.precio;

            let itemDiv = document.createElement("div");
            itemDiv.className = "item-carrito";
            itemDiv.innerHTML= ` 
                <span>${item.emoji || "🛒"} ${item.nombre}</span>
                <span>${item.precio.toFixed(2)}$</span>
            `;
            
            listaCarrito.appendChild(itemDiv);
        }
        Total.innerText =`Total: ${TotalC.toFixed(2)}$`;
    }

    if (contadormenu) {
        contadormenu.innerText =carrito.length;
    }

}

function RecuperarStock(){

    for (let i = 0; i < carrito.length; i++) {
        let itemcarrito = carrito[i];

        for (let j = 0; j < productos.length; j++) {
            if(productos[j].id === itemcarrito.id){

                productos[j].stock++;
                break;
            }
            
        }
        
    }

    localStorage.setItem("productos-admin", JSON.stringify(productos));

    localStorage.setItem("productos-actualizados", Date.now().toString());
};

if (vaciar) {
    vaciar.addEventListener("click", function(){
        if (carrito.length > 0) {
            if(confirm("¿Quiere Vaciar el Carrito?")){

                RecuperarStock();

                carrito = [];
                localStorage.setItem("carrito-cajero", JSON.stringify(carrito));
                MostrarCarrito();
            }
        }else {
            alert("El Carrito ya esta vacío");
        }
    });
}



if (finalizar) {
    finalizar.addEventListener("click", function(){
        if (carrito.length === 0) {
            alert("No hay productos en el carrito");
            return;
        }

        let Ctotal = 0;
        for (let i = 0; i < carrito.length; i++) {
            Ctotal += carrito[i].precio;
        }

        let fecha = new Date();
        let dia = fecha.getDate();
        let mes = fecha.getMonth() + 1;
        let año = fecha.getFullYear();
        let FechaC = dia + "/" + mes + "/" + año;
        
        let ProductosCompra =[];
        for (let i = 0; i < carrito.length; i++) {
            ProductosCompra.push({
                nombre: carrito[i].nombre,
                precio: carrito[i].precio,
                emoji: carrito[i].emoji

            });
        }
        let nuevaCompra ={
            fecha: FechaC,
            total: Ctotal,
            productos: ProductosCompra

        };

        historial.push(nuevaCompra);
        localStorage.setItem("historial-cajero", JSON.stringify(historial));    

        localStorage.setItem("historial-cajero-actualizado", Date.now().toString());

        carrito= [];
        localStorage.setItem("carrito-cajero", JSON.stringify(carrito));

        MostrarCarrito();

        alert("Recibo Emitido ¡Gracias por su compra!✔\nTotal: " + Ctotal.toFixed(2) + "$");

    });
}

if (cerrarsesion) {
    cerrarsesion.addEventListener("click", function(){
        window.location.href = "../index.html";
    });
}

MostrarCarrito();