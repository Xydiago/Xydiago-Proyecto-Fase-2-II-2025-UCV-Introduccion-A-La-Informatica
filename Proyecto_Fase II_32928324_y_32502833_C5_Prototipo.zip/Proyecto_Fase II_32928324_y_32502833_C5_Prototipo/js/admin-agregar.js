let formAgregar = document.getElementById("form-agregar");
let cerrarsesion = document.getElementById("cerrar-sesion");

let  productos = JSON.parse(localStorage.getItem("productos-admin")) || [

    {
        id: 1,
        nombre: "Hamburguesa",
        precio: 6.50,
        stock: 30,
        emoji: "🍔",
        imagen: "../images/1.png"
    },
    {
        id: 2,
        nombre: "Pizza (porción)",
        precio: 5.00,
        stock: 30,
        emoji: "🍕",
        imagen: "../images/2.png"
    },
    {
        id: 3,
        nombre: "Refresco 1L",
        precio: 1.20,
        stock: 30,
        emoji: "🥤",
        imagen: "../images/3.png"
    },
    {
        id: 4,
        nombre: "Empanada",
        precio: 1.00 ,
        stock: 30,
        emoji: "🥟",
        imagen: "../images/4.png"
    },
    {
        id: 5,
        nombre: "Café",
        precio: 2.00,
        stock: 30,
        emoji: "☕",
        imagen: "../images/5.png"
    },
    {
        id: 6,
        nombre: "Tequeños (6 unds)",
        precio: 3.50,
        stock: 30,
        emoji: "🧀",
        imagen: "../images/6.png"
    },
    {   
        id: 7,
        nombre: "Pasticho",
        precio: 8.00,
        stock: 30,
        emoji:"🥘",
        imagen: "../images/7.png"
    },
    {   
        id: 8,
        nombre: "Agua 1.5L",
        precio: 1.90,
        stock: 30,
        emoji:"💧",
        imagen: "../images/8.png",
    },
    {
        id: 9,
        nombre: "Arizona 340ml",
        precio: 2.70,
        stock: 30,
        emoji: "🍹",
        imagen: "../images/9.png"
    },
    {
        id: 10,
        nombre: "Donas",
        precio: 1.20,
        stock: 30,
        emoji: "🍩",
        imagen: "../images/10.png"
    },
];

function convertirBase64(file){

    return new Promise((resolve,reject)  => {

        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(file);

    });
}

async function AgregarProducto(event) {
    event.preventDefault();

    let nombre = document.getElementById("nombre").value.trim();
    let precioTexto = document.getElementById("precio").value.trim();
    let imagen = document.getElementById("imagen");
    let stock = parseInt(document.getElementById("stock").value) || 0;
    let emoji = document.getElementById("emoji").value.trim();


    if (!nombre) {
        
        alert("❌ El nombre del producto es obligatorio");
        return;
    }

    if (!precioTexto) {
        
        alert("❌ El precio es obligatorio");
        return;
    }


    let precio = parseFloat(precioTexto)

    if(isNaN(precio) || precio <= 0){
        alert("❌ El precio debe ser un número  mayor a 0");
        return;
    }

     if (imagen.files.length === 0) {
        alert("❌ Debes seleccionar una imagen");
        return;
     }

    if(!emoji){

        emoji= "🍽️"
    }

    let imagenBase64 = await convertirBase64(imagen.files[0]);    

    let nuevoid=1;
    if(productos.length > 0){

        nuevoid = productos[productos.length -1].id +1;
    }

    let nuevoproducto=
    {
        id: nuevoid,
        nombre: nombre,
        precio: precio,
        stock: stock,
        emoji: emoji,
        imagen: imagenBase64

    };

    productos.push (nuevoproducto);
    localStorage.setItem("productos-admin", JSON.stringify(productos));

    localStorage.setItem("productos-actualizados", Date.now().toString());

    document.getElementById("nombre").value = "";
    document.getElementById("precio").value = "";
    document.getElementById("imagen").value = "";
    document.getElementById("stock").value = "10";
    document.getElementById("emoji").value = "";

    alert(`✅ "${nombre}" agregado correctamente`);


}

if (formAgregar){

    formAgregar.addEventListener("submit", AgregarProducto);
}

if(cerrarsesion){
    
    cerrarsesion.addEventListener("click", function() {
        window.location.href = "../index.html";
    });
}


const inputImagen = document.getElementById('imagen');
const textoArchivo = document.getElementById('nombre-archivo');


inputImagen.addEventListener('change', function() {
    if (this.files && this.files.length > 0) {
        
        const nombre = this.files[0].name;
        textoArchivo.textContent = "✅ " + nombre;
        textoArchivo.style.color = "#27ae60"; 
    } else {
        textoArchivo.textContent = "Ningún archivo seleccionado";
        textoArchivo.style.color = "#7f8c8d";
    }
});